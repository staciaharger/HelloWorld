﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    class MyWorldConsole : BaseHelloWorld
    {
        public void writeHelloWorld()
        {
            this.setGreeting();
            Console.WriteLine(this.myGreeting);
        }
    }
}
