﻿//Stacia Harger
//09OCT2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    class Program
    {

        static void Main(string[] args)
        {
            //This would be used on a server instead of sending the parameter in for the output type.
            String OutputType = args[0];       
         
            switch (OutputType.ToUpper())
            {
                case "CONSOLE":
                    {
                        MyWorldConsole localWorldC = new MyWorldConsole();
                        localWorldC.writeHelloWorld();
                        localWorldC = null;
                    }
                    break;
                case "DATABASE":
                    {
                        MyWorldDatabase localWorldD = new MyWorldDatabase();
                        localWorldD.writeHelloWorld();
                        localWorldD = null;
                    }
                    break;
                case "MOBILE":
                    {
                        MyWorldMobile localWorldM = new MyWorldMobile();
                        localWorldM.writeHelloWorld();
                        localWorldM = null;
                    }
                    break;
                default:
                    {
                        MyWorldConsole localWorld = new MyWorldConsole();
                        localWorld.writeHelloWorld();
                        localWorld = null;
                    }
                    break;
            }
        }
    }
}
